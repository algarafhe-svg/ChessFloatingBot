package com.example.chessfloatingbot

import android.app.Service
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.os.Build
import android.os.IBinder
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class FloatingControlsService : Service() {
    private lateinit var wm: WindowManager
    private var panel: View? = null
    private lateinit var status: TextView
    private var state = State.STOPPED
    private val statusReceiver = object : android.content.BroadcastReceiver() {
        override fun onReceive(context: android.content.Context?, intent: Intent?) {
            if (::status.isInitialized) status.text = intent?.getStringExtra("status") ?: status.text
        }
    }
    private enum class State { STOPPED, RUNNING, PAUSED }

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val statusFilter = android.content.IntentFilter(ScreenCaptureBotService.ACTION_STATUS)
        if (Build.VERSION.SDK_INT >= 33) registerReceiver(statusReceiver, statusFilter, android.content.Context.RECEIVER_NOT_EXPORTED)
        else {
            @Suppress("DEPRECATION")
            registerReceiver(statusReceiver, statusFilter)
        }
        if (Build.VERSION.SDK_INT >= 23 && !android.provider.Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "فعّل إذن الظهور فوق التطبيقات أولاً", Toast.LENGTH_LONG).show()
            stopSelf(); return
        }
        showPanel()
    }

    private fun showPanel() {
        val density = resources.displayMetrics.density
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding((9*density).toInt(), (7*density).toInt(), (9*density).toInt(), (7*density).toInt())
            setBackgroundColor(Color.argb(235, 15, 35, 27))
        }
        status = TextView(this).apply {
            text = "Chess Bot: متوقف"; setTextColor(Color.WHITE); textSize = 12f
            setPadding(4, 2, 4, (5*density).toInt())
        }
        root.addView(status)
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        fun makeButton(label: String, color: Int, action: () -> Unit) {
            val b = Button(this).apply {
                text = label; textSize = 11f; isAllCaps = false
                setTextColor(Color.WHITE); setBackgroundColor(color)
                setOnClickListener { action() }
            }
            row.addView(b, LinearLayout.LayoutParams(0, (43*density).toInt(), 1f))
        }
        makeButton("START", Color.rgb(28,125,72)) { startBot() }
        makeButton("PAUSE", Color.rgb(175,125,20)) { pauseBot() }
        makeButton("STOP", Color.rgb(165,35,42)) { stopBot() }
        root.addView(row)
        // Drag from status strip; buttons remain clickable.
        status.setOnTouchListener(object : View.OnTouchListener {
            var sx=0f; var sy=0f; var wx=0; var wy=0
            override fun onTouch(v: View, e: MotionEvent): Boolean {
                val lp = panel?.layoutParams as? WindowManager.LayoutParams ?: return false
                when(e.action) {
                    MotionEvent.ACTION_DOWN -> { sx=e.rawX; sy=e.rawY; wx=lp.x; wy=lp.y; return true }
                    MotionEvent.ACTION_MOVE -> { lp.x=wx+(e.rawX-sx).toInt(); lp.y=wy+(e.rawY-sy).toInt(); wm.updateViewLayout(panel,lp); return true }
                }
                return true
            }
        })
        val type = if (Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY else WindowManager.LayoutParams.TYPE_PHONE
        val lp = WindowManager.LayoutParams(WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
            type, WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT).apply { gravity=Gravity.TOP or Gravity.START; x=(12*density).toInt(); y=(100*density).toInt() }
        panel=root
        wm.addView(root,lp)
    }

    private fun broadcast(action: String) { sendBroadcast(Intent(action).setPackage(packageName)) }
    private fun startBot() {
        state=State.RUNNING; status.text="Chess Bot: يعمل — بانتظار تحليل الرقعة"
        broadcast(ACTION_START)
        Toast.makeText(this,"بدأ التحليل. لم يتم تفعيل اللعب التلقائي حتى تكتمل معايرة الرقعة.",Toast.LENGTH_SHORT).show()
    }
    private fun pauseBot() { state=State.PAUSED; status.text="Chess Bot: متوقف مؤقتاً"; broadcast(ACTION_PAUSE) }
    private fun stopBot() { state=State.STOPPED; status.text="Chess Bot: متوقف"; broadcast(ACTION_STOP) }
    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int = START_STICKY
    override fun onDestroy() { try { unregisterReceiver(statusReceiver) } catch (_: Exception) {}; panel?.let { try { wm.removeView(it) } catch (_: Exception) {} }; panel=null; super.onDestroy() }
    override fun onBind(intent: Intent?): IBinder? = null
    companion object {
        const val ACTION_START="com.example.chessfloatingbot.START"
        const val ACTION_PAUSE="com.example.chessfloatingbot.PAUSE"
        const val ACTION_STOP="com.example.chessfloatingbot.STOP"
    }
}
