package com.example.chessfloatingbot

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import kotlin.math.sqrt

/** Multi-exemplar silhouette matcher. Player ownership is mapped by the lower-side piece style. */
class TemplatePieceRecognizer(context: Context) {
    data class Match(val kind: Char, val belongsToBottomPlayer: Boolean, val score: Double)
    private data class Template(val kind: Char, val pixels: IntArray)
    private val templates = mutableListOf<Template>()

    init {
        val files = context.assets.list("pieces/exemplars") ?: emptyArray()
        for (file in files.filter { it.endsWith(".png") }) {
            val kind = file.substringAfter('_').firstOrNull() ?: continue
            if (kind !in "pnbrqk") continue
            val bitmap = context.assets.open("pieces/exemplars/$file").use { BitmapFactory.decodeStream(it) } ?: continue
            templates += Template(kind, bitmapMask(bitmap))
            bitmap.recycle()
        }
        require(templates.size >= 24) { "Piece templates are incomplete: ${templates.size}/32" }
    }

    fun hasPieceCandidate(square: Bitmap): Boolean = foregroundMask(square).count { it != 0 } >= 55

    fun classify(square: Bitmap): Match? {
        val raw = foregroundMask(square)
        if (raw.count { it != 0 } < 55) return null
        val candidate = normalize(raw)
        val byKind = templates.groupBy { it.kind }.mapValues { (_, items) ->
            items.maxOf { iou(candidate, it.pixels) }
        }
        val ranked = byKind.entries.sortedByDescending { it.value }
        val best = ranked.firstOrNull() ?: return null
        val second = ranked.getOrNull(1)?.value ?: 0.0
        if (best.value < 0.34 || best.value - second < 0.035) return null
        val lowerSide = medianForegroundRed(square) > 125.0
        return Match(best.key, lowerSide, best.value)
    }

    private fun bitmapMask(bitmap: Bitmap): IntArray {
        val scaled = Bitmap.createScaledBitmap(bitmap, 48, 48, true)
        val px = IntArray(48 * 48)
        scaled.getPixels(px, 0, 48, 0, 0, 48, 48)
        scaled.recycle()
        return IntArray(px.size) { if ((px[it] and 255) > 127) 1 else 0 }
    }

    private fun foregroundMask(square: Bitmap): IntArray {
        val scaled = Bitmap.createScaledBitmap(square, 48, 48, true)
        val px = IntArray(48 * 48)
        scaled.getPixels(px, 0, 48, 0, 0, 48, 48)
        scaled.recycle()
        val corners = intArrayOf(px[3*48+3], px[3*48+44], px[44*48+3], px[44*48+44])
        val bg = floatArrayOf(
            corners.map { ((it shr 16) and 255).toFloat() }.average().toFloat(),
            corners.map { ((it shr 8) and 255).toFloat() }.average().toFloat(),
            corners.map { (it and 255).toFloat() }.average().toFloat()
        )
        return IntArray(px.size) { i ->
            val c=px[i]
            val dr=((c shr 16) and 255)-bg[0]
            val dg=((c shr 8) and 255)-bg[1]
            val db=(c and 255)-bg[2]
            if (dr*dr+dg*dg+db*db > 55f*55f) 1 else 0
        }
    }

    private fun normalize(mask: IntArray): IntArray {
        var minX=48; var minY=48; var maxX=-1; var maxY=-1
        for (i in mask.indices) if (mask[i] != 0) {
            val x=i%48; val y=i/48
            if(x<minX)minX=x; if(x>maxX)maxX=x; if(y<minY)minY=y; if(y>maxY)maxY=y
        }
        if(maxX<minX || maxY<minY) return IntArray(2304)
        val w=maxX-minX+1; val h=maxY-minY+1
        val scale=minOf(42.0/w,44.0/h)
        val nw=(w*scale).toInt().coerceAtLeast(1); val nh=(h*scale).toInt().coerceAtLeast(1)
        val out=IntArray(2304)
        for(y in 0 until nh) for(x in 0 until nw) {
            val sx=minX+(x/scale).toInt().coerceIn(0,w-1)
            val sy=minY+(y/scale).toInt().coerceIn(0,h-1)
            out[((48-nh)/2+y)*48+(48-nw)/2+x]=mask[sy*48+sx]
        }
        return out
    }

    private fun iou(a:IntArray,b:IntArray):Double {
        var intersection=0; var union=0
        for(i in a.indices) { if(a[i]!=0 && b[i]!=0)intersection++; if(a[i]!=0 || b[i]!=0)union++ }
        return if(union==0)0.0 else intersection.toDouble()/union
    }

    private fun medianForegroundRed(square: Bitmap): Double {
        val scaled=Bitmap.createScaledBitmap(square,48,48,true)
        val px=IntArray(2304); scaled.getPixels(px,0,48,0,0,48,48); scaled.recycle()
        val mask=foregroundMask(square)
        val values=px.indices.filter { mask[it]!=0 }.map { i ->
            val c=px[i]; ((c shr 16) and 255)
        }.sorted()
        if(values.isEmpty()) return 0.0
        return values[values.size/2].toDouble()
    }
}
