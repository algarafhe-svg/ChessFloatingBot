package com.example.chessfloatingbot

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.graphics.RectF
import kotlin.math.roundToInt

/**
 * Executes a Stockfish UCI move on a calibrated 8x8 board.
 * The caller must first verify it is the bottom player's turn and must re-capture
 * the board after this callback to verify that the move actually happened.
 */
object BoardMoveExecutor {
    fun dispatch(
        service: AccessibilityService,
        uci: String,
        board: RectF,
        callback: (Boolean) -> Unit
    ) {
        val move = BoardFenEncoder.parseUciMove(uci)
            ?: run { callback(false); return }
        require(board.width() > 0 && board.height() > 0)
        val from = squareCenter(move.first, board)
        val to = squareCenter(move.second, board)
        val path = Path().apply {
            moveTo(from.first, from.second)
            lineTo(to.first, to.second)
        }
        val gesture = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0, 420))
            .build()
        callback(service.dispatchGesture(gesture, null, null))
    }

    private fun squareCenter(square: String, board: RectF): Pair<Float, Float> {
        val file = square[0] - 'a'
        val rank = square[1] - '1'
        val cellW = board.width() / 8f
        val cellH = board.height() / 8f
        // Rank 8 is the top row; rank 1 is the bottom row.
        val col = file
        val row = 7 - rank
        return Pair(
            board.left + (col + 0.5f) * cellW,
            board.top + (row + 0.5f) * cellH
        )
    }
}
