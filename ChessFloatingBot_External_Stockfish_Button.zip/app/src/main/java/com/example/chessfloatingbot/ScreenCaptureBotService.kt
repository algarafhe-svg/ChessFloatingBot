package com.example.chessfloatingbot

import android.app.*
import android.content.*
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.*
import android.util.DisplayMetrics
import android.view.WindowManager
import java.io.File
import java.util.concurrent.atomic.AtomicBoolean

/** MediaProjection capture + Stockfish loop. START must be pressed on the bottom player's turn. */
class ScreenCaptureBotService : Service() {
    private var projection: MediaProjection? = null
    private var projectionCallback: MediaProjection.Callback? = null
    private var display: VirtualDisplay? = null
    private var reader: ImageReader? = null
    private var engine: StockfishEngine? = null
    private var vision: BoardVisionPipeline? = null
    private var worker: HandlerThread? = null
    private var handler: Handler? = null
    private var running = false
    private var paused = false
    private var lastFen: String? = null
    private var pendingFrom: String? = null
    private var pendingTo: String? = null
    private var pendingUci: String? = null
    private var verificationAttempts = 0
    private var waitingOpponentFen: String? = null
    private val busy = AtomicBoolean(false)
    private val commands = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            when (intent?.action) {
                FloatingControlsService.ACTION_START -> startLoop()
                FloatingControlsService.ACTION_PAUSE -> { paused = true; status("متوقف مؤقتاً") }
                FloatingControlsService.ACTION_STOP -> {
                    running = false; paused = false; lastFen = null
                    pendingFrom = null; pendingTo = null; pendingUci = null; waitingOpponentFen = null
                    status("تم الإيقاف")
                }
                ACTION_RELOAD_ENGINE -> handler?.post { reloadEngine() }
            }
        }
    }

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(41, notification("جاهز لالتقاط شاشة اللعبة"),
                android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
        } else {
            startForeground(41, notification("جاهز لالتقاط شاشة اللعبة"))
        }
        worker = HandlerThread("chess-capture-worker").also { it.start() }
        handler = Handler(worker!!.looper)
        val filter = IntentFilter().apply {
            addAction(FloatingControlsService.ACTION_START)
            addAction(FloatingControlsService.ACTION_PAUSE)
            addAction(FloatingControlsService.ACTION_STOP)
            addAction(ACTION_RELOAD_ENGINE)
        }
        if (Build.VERSION.SDK_INT >= 33) registerReceiver(commands, filter, Context.RECEIVER_NOT_EXPORTED)
        else {
            @Suppress("DEPRECATION")
            registerReceiver(commands, filter)
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val code = intent?.getIntExtra(EXTRA_RESULT_CODE, Activity.RESULT_CANCELED) ?: Activity.RESULT_CANCELED
        val data = if (Build.VERSION.SDK_INT >= 33) intent?.getParcelableExtra(EXTRA_RESULT_DATA, Intent::class.java)
                   else {
                       @Suppress("DEPRECATION")
                       intent?.getParcelableExtra(EXTRA_RESULT_DATA)
                   }
        if (projection == null && code == Activity.RESULT_OK && data != null) setupProjection(code, data)
        return START_STICKY
    }

    private fun setupProjection(code: Int, data: Intent) {
        try {
            val mgr = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
            projection = mgr.getMediaProjection(code, data)
            projectionCallback = object : MediaProjection.Callback() {
                override fun onStop() {
                    running = false
                    status("أوقف Android مشاركة الشاشة")
                    stopSelf()
                }
            }
            projection!!.registerCallback(projectionCallback!!, handler)
            val metrics = DisplayMetrics()
            @Suppress("DEPRECATION")
            (getSystemService(WINDOW_SERVICE) as WindowManager).defaultDisplay.getRealMetrics(metrics)
            val w = metrics.widthPixels; val h = metrics.heightPixels; val dpi = metrics.densityDpi
            reader = ImageReader.newInstance(w, h, PixelFormat.RGBA_8888, 3)
            display = projection!!.createVirtualDisplay("ChessBotCapture", w, h, dpi,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, reader!!.surface, null, handler)
            vision = BoardVisionPipeline(TemplatePieceRecognizer(this))
            engine = StockfishEngine(EngineBinaryStore.selected(this)).also { it.start(); it.configure(2, 96) }
            status("التقاط الشاشة والمحرك جاهزان؛ اضغط START في اللوحة العائمة")
        } catch (e: Exception) { status("تعذر بدء التقاط الشاشة: ${e.message}") }
    }


    private fun reloadEngine() {
        val wasRunning = running
        running = false
        paused = false
        try {
            engine?.close()
            engine = StockfishEngine(EngineBinaryStore.selected(this)).also {
                val id = it.start()
                it.configure(2, 96)
                status("تم تحميل المحرك المحدد: $id")
            }
            lastFen = null
            pendingFrom = null; pendingTo = null; pendingUci = null; waitingOpponentFen = null
            if (wasRunning) {
                running = true
                handler?.post { cycle(initial = true) }
            }
        } catch (e: Exception) {
            engine = null
            status("فشل تحميل المحرك المحدد: ${e.message}")
        }
    }

    private fun startLoop() {
        if (projection == null || engine == null || vision == null) {
            status("امنح إذن التقاط الشاشة من التطبيق أولاً"); return
        }
        if (running && paused) {
            paused = false
            status("استئناف الحالة السابقة")
            when {
                pendingFrom != null && pendingTo != null && pendingUci != null ->
                    handler?.post { verifyMove(pendingFrom!!, pendingTo!!, pendingUci!!) }
                waitingOpponentFen != null -> handler?.post { waitOpponent(waitingOpponentFen!!) }
                else -> handler?.post { cycle(initial = lastFen == null) }
            }
            return
        }
        running = true; paused = false; lastFen = null
        pendingFrom = null; pendingTo = null; pendingUci = null; waitingOpponentFen = null
        status("يحلل الرقعة؛ اضغط START فقط عندما يكون دور اللاعب السفلي")
        handler?.post { cycle(initial = true) }
    }

    private fun cycle(initial: Boolean = false) {
        if (!running || paused || !busy.compareAndSet(false, true)) return
        try {
            val shot = captureFrame()
            if (shot == null) { status("بانتظار إطار شاشة صالح"); schedule(900); return }
            val board = try { vision!!.analyze(shot, bottomPlayerToMove = true) } finally { shot.recycle() }
            if (board == null) { status("لم تُقرأ الرقعة بثقة كافية؛ إعادة المحاولة دون تنفيذ نقلة"); schedule(1100); return }
            if (!initial && lastFen != null && board.fen == lastFen) { schedule(900); return }
            status("قُرئت الرقعة: ${board.detectedPieces} قطعة؛ تحليل Stockfish…")
            val answer = engine!!.bestMove(board.fen, 1400)
            val coords = BoardFenEncoder.parseUciMove(answer.bestMove)
            if (coords == null) { status("لم يُرجع المحرك نقلة قابلة للتنفيذ"); schedule(1200); return }
            val before = board.fen
            lastFen = before
            pendingFrom = coords.first; pendingTo = coords.second; pendingUci = answer.bestMove
            verificationAttempts = 0
            status("أفضل نقلة ${answer.bestMove}؛ تنفيذها…")
            sendGesture(board.boardBounds, answer.bestMove)
        } catch (e: Exception) { status("توقف آمن: ${e.message}"); schedule(1600) }
        finally { busy.set(false) }
    }

    private fun sendGesture(bounds: android.graphics.RectF, uci: String) {
        val move = BoardFenEncoder.parseUciMove(uci) ?: return
        dispatchUciGesture(bounds, uci)
        // Castling is two piece movements in the UI: move the rook after the king.
        val castleRook = when (uci.substring(0, 4)) {
            "e1g1" -> "h1f1"; "e1c1" -> "a1d1"; "e8g8" -> "h8f8"; "e8c8" -> "a8d8"; else -> null
        }
        if (castleRook != null) handler?.postDelayed({ dispatchUciGesture(bounds, castleRook) }, 600)
        // Verify by a fresh screenshot: origin should be empty and destination occupied.
        handler?.postDelayed({ verifyMove(move.first, move.second, uci) }, if (castleRook != null) 1450 else 850)
    }

    private fun dispatchUciGesture(bounds: android.graphics.RectF, uci: String) {
        val move = BoardFenEncoder.parseUciMove(uci) ?: return
        val cell = bounds.width()/8f
        fun point(s: String): Pair<Float,Float> {
            val file=s[0]-'a'; val rank=s[1]-'1'; val row=7-rank
            return Pair(bounds.left+(file+0.5f)*cell,bounds.top+(row+0.5f)*cell)
        }
        val a=point(move.first); val b=point(move.second)
        sendBroadcast(Intent(ChessAccessibilityService.ACTION_EXECUTE_MOVE).setPackage(packageName)
            .putExtra("fromX",a.first).putExtra("fromY",a.second).putExtra("toX",b.first).putExtra("toY",b.second)
            .putExtra("uci",uci))
    }

    private fun verifyMove(from: String, to: String, uci: String) {
        if (!running || paused) return
        val shot=captureFrame() ?: run { retryVerification(from, to, uci, "لا توجد لقطة شاشة للتحقق"); return }
        val board=try { vision!!.analyze(shot, true) } finally { shot.recycle() }
        if (board == null) { retryVerification(from, to, uci, "تعذر قراءة الرقعة للتحقق"); return }
        val fromIndex=(7-(from[1]-'1'))*8+(from[0]-'a')
        val toIndex=(7-(to[1]-'1'))*8+(to[0]-'a')
        val ranks=board.fen.substringBefore(' ').split('/')
        fun occupied(index:Int):Boolean {
            val row=index/8; val col=index%8; var file=0
            for(ch in ranks[row]) { if(ch.isDigit()) file+=ch.digitToInt() else { if(file==col) return true; file++ } }
            return false
        }
        if (!occupied(fromIndex) && occupied(toIndex) && board.fen != lastFen) {
            status("تم التحقق مبدئياً من تنفيذ $uci؛ انتظار دور الخصم")
            lastFen=board.fen
            waitingOpponentFen=board.fen
            pendingFrom=null; pendingTo=null; pendingUci=null; verificationAttempts=0
            // Wait for opponent move (another board change), then run engine for bottom side.
            waitOpponent(board.fen)
        } else {
            retryVerification(from, to, uci, "لم يتغير مربعا النقلة كما هو متوقع")
        }
    }

    private fun retryVerification(from:String, to:String, uci:String, reason:String) {
        verificationAttempts++
        if (verificationAttempts <= 3) {
            status("$reason؛ محاولة تحقق ${verificationAttempts}/3")
            handler?.postDelayed({ verifyMove(from,to,uci) }, 900)
        } else {
            running=false
            status("توقفت بأمان: لم أستطع إثبات نجاح النقلة $uci. راجع الرقعة وأعد START في دورك.")
        }
    }

    private fun waitOpponent(ownMoveFen:String) {
        handler?.postDelayed({
            if (!running || paused) return@postDelayed
            val shot=captureFrame() ?: run { waitOpponent(ownMoveFen); return@postDelayed }
            val board=try { vision!!.analyze(shot, true) } finally { shot.recycle() }
            if (board == null || board.fen == ownMoveFen) waitOpponent(ownMoveFen)
            else {
                confirmOpponentPosition(ownMoveFen, board.fen)
            }
        }, 1100)
    }

    private fun confirmOpponentPosition(ownMoveFen:String, candidateFen:String) {
        handler?.postDelayed({
            if (!running || paused) return@postDelayed
            val shot=captureFrame() ?: run { waitOpponent(ownMoveFen); return@postDelayed }
            val board=try { vision!!.analyze(shot, true) } finally { shot.recycle() }
            if (board != null && board.fen == candidateFen) {
                status("تم تأكيد استقرار رد الخصم؛ تحليل دور اللاعب السفلي")
                lastFen=board.fen
                waitingOpponentFen=null
                cycle(initial=true)
            } else waitOpponent(ownMoveFen)
        }, 550)
    }

    private fun captureFrame(): Bitmap? {
        val image=reader?.acquireLatestImage() ?: return null
        try {
            val plane=image.planes[0]; val buffer=plane.buffer
            val pixelStride=plane.pixelStride; val rowStride=plane.rowStride
            val rowPadding=rowStride-pixelStride*image.width
            val padded=Bitmap.createBitmap(image.width+rowPadding/pixelStride,image.height,Bitmap.Config.ARGB_8888)
            padded.copyPixelsFromBuffer(buffer)
            val cropped=Bitmap.createBitmap(padded,0,0,image.width,image.height)
            padded.recycle(); return cropped
        } finally { image.close() }
    }

    private fun schedule(delay:Long) { if(running && !paused) handler?.postDelayed({ cycle() },delay) }
    private fun status(s:String) { getSystemService(NOTIFICATION_SERVICE).let { (it as NotificationManager).notify(41,notification(s)) }; sendBroadcast(Intent(ACTION_STATUS).setPackage(packageName).putExtra("status",s)) }
    private fun notification(s:String): Notification {
        val builder = if (Build.VERSION.SDK_INT >= 26) Notification.Builder(this, CHANNEL) else Notification.Builder(this)
        return builder.setContentTitle("Chess Stockfish").setContentText(s)
            .setSmallIcon(android.R.drawable.ic_media_play).setOngoing(true).build()
    }
    private fun createNotificationChannel() { if(Build.VERSION.SDK_INT>=26) (getSystemService(NOTIFICATION_SERVICE) as NotificationManager).createNotificationChannel(NotificationChannel(CHANNEL,"Chess capture",NotificationManager.IMPORTANCE_LOW)) }
    override fun onDestroy() { running=false; try{unregisterReceiver(commands)}catch(_:Exception){}; display?.release(); reader?.close(); projectionCallback?.let { try { projection?.unregisterCallback(it) } catch (_: Exception) {} }; projection?.stop(); engine?.close(); worker?.quitSafely(); super.onDestroy() }
    override fun onBind(intent:Intent?)=null
    companion object { const val EXTRA_RESULT_CODE="resultCode"; const val EXTRA_RESULT_DATA="resultData"; const val ACTION_STATUS="com.example.chessfloatingbot.STATUS"; const val CHANNEL="chess_capture"; const val ACTION_RELOAD_ENGINE="com.example.chessfloatingbot.RELOAD_ENGINE" }
}
