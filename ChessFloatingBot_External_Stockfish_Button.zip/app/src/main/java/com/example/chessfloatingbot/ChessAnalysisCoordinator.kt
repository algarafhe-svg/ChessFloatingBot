package com.example.chessfloatingbot

import android.graphics.Bitmap

/**
 * Single pipeline entry point: screenshot -> board detection -> normalized FEN ->
 * Stockfish best move. It never sends a move when vision is uncertain or it is not
 * the bottom player's turn.
 */
class ChessAnalysisCoordinator(
    private val vision: BoardVisionPipeline,
    private val engine: StockfishEngine
) {
    data class Decision(
        val fen: String,
        val bestMoveUci: String,
        val detectedPieces: Int,
        val visionConfidence: Double,
        val engineInfo: String
    )

    fun analyzeScreenshot(
        screenshot: Bitmap,
        bottomPlayerToMove: Boolean,
        moveTimeMs: Int = 1200
    ): Decision? {
        if (!bottomPlayerToMove) return null
        val board = vision.analyze(screenshot, bottomPlayerToMove = true) ?: return null
        val answer = engine.bestMove(board.fen, moveTimeMs)
        if (BoardFenEncoder.parseUciMove(answer.bestMove) == null) return null
        return Decision(board.fen, answer.bestMove, board.detectedPieces, board.confidence, answer.info)
    }
}
