package com.example.chessfloatingbot

import android.app.Activity
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.content.Intent
import android.net.Uri
import android.provider.Settings
import android.os.Bundle
import android.graphics.Color
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import java.util.concurrent.Executors

class MainActivity : Activity() {
    private val worker = Executors.newSingleThreadExecutor()
    private var engine: StockfishEngine? = null
    private lateinit var status: TextView
    private lateinit var fen: EditText
    private lateinit var result: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val pad = (16 * resources.displayMetrics.density).toInt()
        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(pad, pad, pad, pad)
            setBackgroundColor(Color.rgb(15, 42, 31))
        }
        fun label(text: String, size: Float = 16f) = TextView(this).apply {
            this.text = text; textSize = size; setTextColor(Color.WHITE)
        }
        content.addView(label("Chess • Stockfish محلي", 24f))
        content.addView(label("اختبار المحرك على الهاتف — لا يحتاج محاكي أو اتصالاً أثناء التحليل"))
        status = label("الحالة: لم يتم تشغيل المحرك")
        content.addView(status)
        fen = EditText(this).apply {
            setText("rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1")
            setTextColor(Color.WHITE); setHintTextColor(Color.LTGRAY); setHint("FEN")
            setSingleLine(false); minLines = 3
        }
        content.addView(fen, LinearLayout.LayoutParams(-1, ViewGroup.LayoutParams.WRAP_CONTENT))
        val start = Button(this).apply { text = "تشغيل Stockfish" }
        val analyze = Button(this).apply { text = "حلّل الوضعية وأظهر أفضل نقلة" }
        val stop = Button(this).apply { text = "إيقاف المحرك" }
        val overlay = Button(this).apply { text = "تفعيل لوحة START / PAUSE / STOP العائمة" }
        val accessibility = Button(this).apply { text = "فتح إعدادات إمكانية الوصول" }
        val capture = Button(this).apply { text = "السماح بالتقاط شاشة اللعبة" }
        val addEngine = Button(this).apply { text = "إضافة محرك Stockfish خارجي" }
        val bundledEngine = Button(this).apply { text = "استخدام محرك Stockfish المرفق" }
        result = label("النتيجة ستظهر هنا", 18f)
        content.addView(start); content.addView(analyze); content.addView(stop)
        content.addView(addEngine); content.addView(bundledEngine)
        content.addView(capture); content.addView(overlay); content.addView(accessibility); content.addView(result)
        addEngine.setOnClickListener {
            val pick = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                addCategory(Intent.CATEGORY_OPENABLE)
                type = "*/*"
            }
            startActivityForResult(pick, REQUEST_ENGINE)
        }
        bundledEngine.setOnClickListener {
            EngineBinaryStore.useBundled(this)
            status.text = "تم اختيار محرك Stockfish المرفق بالتطبيق"
        }
        capture.setOnClickListener {
            val manager = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
            startActivityForResult(manager.createScreenCaptureIntent(), REQUEST_CAPTURE)
        }
        overlay.setOnClickListener {
            if (!Settings.canDrawOverlays(this)) {
                startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            } else {
                startService(Intent(this, FloatingControlsService::class.java))
                status.text = "لوحة التحكم العائمة تعمل"
            }
        }
        accessibility.setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        start.setOnClickListener {
            status.text = "الحالة: جارٍ تشغيل المحرك..."
            worker.execute {
                try {
                    val e = StockfishEngine(EngineBinaryStore.selected(this))
                    val handshake = e.start(); e.configure(threads = 2, hashMb = 64)
                    engine?.close(); engine = e
                    runOnUiThread { status.text = "الحالة: Stockfish جاهز\n$handshake" }
                } catch (ex: Exception) { runOnUiThread { status.text = "فشل تشغيل المحرك: ${ex.message}" } }
            }
        }
        analyze.setOnClickListener {
            val position = fen.text.toString().trim()
            status.text = "الحالة: تحليل..."
            worker.execute {
                try {
                    val answer = engine?.bestMove(position, 1500) ?: error("شغّل المحرك أولاً")
                    runOnUiThread { status.text = "أفضل نقلة: ${answer.bestMove}"; result.text = answer.info }
                } catch (ex: Exception) { runOnUiThread { status.text = "تعذر التحليل: ${ex.message}" } }
            }
        }
        stop.setOnClickListener { worker.execute { engine?.close(); engine = null; runOnUiThread { status.text = "الحالة: متوقف" } } }
        setContentView(ScrollView(this).apply { addView(content) })
    }
    @Deprecated("Legacy result callback retained for API 23+")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQUEST_ENGINE) {
            if (resultCode == RESULT_OK && data?.data != null) {
                status.text = "جارٍ استيراد وفحص ملف المحرك..."
                val selectedUri = data.data!!
                worker.execute {
                    try {
                        val imported = EngineBinaryStore.importEngine(this, selectedUri)
                        sendBroadcast(Intent(ScreenCaptureBotService.ACTION_RELOAD_ENGINE).setPackage(packageName))
                        runOnUiThread {
                            status.text = "تمت إضافة المحرك الخارجي: ${imported.name}. أوقف المحرك الحالي ثم شغّله مجدداً."
                        }
                    } catch (e: Exception) {
                        runOnUiThread { status.text = "رفض ملف المحرك: ${e.message}" }
                    }
                }
            } else status.text = "لم يتم اختيار ملف محرك."
            return
        }
        if (requestCode == REQUEST_CAPTURE) {
            if (resultCode == RESULT_OK && data != null) {
                val service = Intent(this, ScreenCaptureBotService::class.java)
                    .putExtra(ScreenCaptureBotService.EXTRA_RESULT_CODE, resultCode)
                    .putExtra(ScreenCaptureBotService.EXTRA_RESULT_DATA, data)
                if (Build.VERSION.SDK_INT >= 26) startForegroundService(service) else startService(service)
                status.text = "تم منح إذن التقاط الشاشة؛ افتح جواكر ثم اضغط START من اللوحة العائمة عند دورك."
            } else status.text = "لم يتم منح إذن التقاط الشاشة."
        }
    }
    override fun onDestroy() { worker.execute { engine?.close() }; worker.shutdown(); super.onDestroy() }
    companion object { private const val REQUEST_CAPTURE = 7401; private const val REQUEST_ENGINE = 7402 }
}
