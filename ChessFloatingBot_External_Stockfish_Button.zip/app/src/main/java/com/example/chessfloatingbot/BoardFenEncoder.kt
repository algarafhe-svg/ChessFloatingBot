package com.example.chessfloatingbot

/**
 * Board is supplied top rank to bottom rank, left to right (a8..h1).
 * Side identity is based on the piece's visual family in the game, then normalized:
 * pieces belonging to the player at the bottom become uppercase (Stockfish white).
 * The player-to-move flag must come from turn-indicator detection, not guessed.
 */
object BoardFenEncoder {
    data class DetectedPiece(val kind: Char, val belongsToBottomPlayer: Boolean)
    data class Position(val squares: List<DetectedPiece?>, val bottomPlayerToMove: Boolean)

    fun encode(position: Position, halfmoveClock: Int = 0, fullmoveNumber: Int = 1): String {
        require(position.squares.size == 64) { "Expected exactly 64 squares" }
        require(position.squares.all { it == null || it.kind.lowercaseChar() in "pnbrqk" }) {
            "Piece kind must be one of p,n,b,r,q,k"
        }
        val rows = (0..7).map { row ->
            val out = StringBuilder()
            var empty = 0
            for (col in 0..7) {
                val piece = position.squares[row * 8 + col]
                if (piece == null) empty++ else {
                    if (empty > 0) { out.append(empty); empty = 0 }
                    val normalized = piece.kind.lowercaseChar()
                    out.append(if (piece.belongsToBottomPlayer) normalized.uppercaseChar() else normalized)
                }
            }
            if (empty > 0) out.append(empty)
            out.toString()
        }.joinToString("/")
        val side = if (position.bottomPlayerToMove) "w" else "b"
        return "$rows $side - - ${halfmoveClock.coerceAtLeast(0)} ${fullmoveNumber.coerceAtLeast(1)}"
    }

    fun startingPosition(): String =
        "rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w - - 0 1"

    fun parseUciMove(move: String): Pair<String, String>? {
        if (!move.matches(Regex("[a-h][1-8][a-h][1-8][qrbn]?"))) return null
        return move.substring(0, 2) to move.substring(2, 4)
    }
}
