package com.example.chessfloatingbot

import java.io.BufferedReader
import java.io.BufferedWriter
import java.io.File
import java.io.InputStreamReader
import java.io.OutputStreamWriter
import java.util.concurrent.TimeUnit

/** Local UCI bridge for the packaged or user-imported Android Stockfish executable. */
class StockfishEngine(private val binary: File) : AutoCloseable {
    private var process: Process? = null
    private var input: BufferedWriter? = null
    private var output: BufferedReader? = null

    @Synchronized fun start(): String {
        if (process?.isAlive == true) return "Stockfish is already running"
        require(binary.exists() && binary.isFile && binary.canExecute()) {
            "Stockfish binary missing or not executable for this CPU ABI: ${binary.absolutePath}"
        }
        process = ProcessBuilder(binary.absolutePath)
            .redirectErrorStream(true)
            .start()
        input = BufferedWriter(OutputStreamWriter(process!!.outputStream))
        output = BufferedReader(InputStreamReader(process!!.inputStream))
        send("uci")
        val id = readUntil("uciok", 8)
        send("isready")
        readUntil("readyok", 8)
        return id.ifBlank { "Stockfish UCI ready" }
    }

    @Synchronized fun configure(threads: Int = 2, hashMb: Int = 64) {
        check(process?.isAlive == true) { "Engine is not started" }
        send("setoption name Threads value ${threads.coerceIn(1, 4)}")
        send("setoption name Hash value ${hashMb.coerceIn(16, 256)}")
        send("isready"); readUntil("readyok", 8)
    }

    @Synchronized fun bestMove(fen: String, moveTimeMs: Int = 1200): EngineResult {
        require(fen.split(' ').size >= 4) { "Invalid FEN" }
        check(process?.isAlive == true) { "Engine is not started" }
        send("ucinewgame")
        send("position fen $fen")
        send("go movetime ${moveTimeMs.coerceIn(100, 5000)}")
        var best = ""
        var ponder: String? = null
        var info = ""
        val deadline = System.nanoTime() + TimeUnit.MILLISECONDS.toNanos(moveTimeMs.coerceIn(100, 5000) + 7000L)
        while (System.nanoTime() < deadline) {
            val line = output?.readLine() ?: break
            if (line.startsWith("info depth")) info = line
            if (line.startsWith("bestmove ")) {
                val parts = line.trim().split(Regex("\\s+"))
                best = parts.getOrNull(1) ?: ""
                ponder = parts.getOrNull(3)?.takeIf { it != "(none)" }
                break
            }
        }
        check(best.isNotBlank() && best != "(none)") { "Stockfish returned no legal move. Position may be terminal or engine timed out." }
        return EngineResult(best, ponder, info)
    }

    private fun send(command: String) { input?.apply { write(command); newLine(); flush() } }
    private fun readUntil(marker: String, seconds: Long): String {
        val deadline = System.nanoTime() + TimeUnit.SECONDS.toNanos(seconds)
        val lines = StringBuilder()
        while (System.nanoTime() < deadline) {
            val line = output?.readLine() ?: break
            lines.append(line).append('\n')
            if (line.contains(marker)) break
        }
        check(lines.contains(marker)) { "Stockfish handshake timed out waiting for $marker" }
        return lines.toString()
    }

    @Synchronized override fun close() {
        try { send("quit") } catch (_: Exception) {}
        try { process?.waitFor(1500, TimeUnit.MILLISECONDS) } catch (_: Exception) {}
        process?.destroy()
        input = null; output = null; process = null
    }
}
data class EngineResult(val bestMove: String, val ponder: String?, val info: String)
