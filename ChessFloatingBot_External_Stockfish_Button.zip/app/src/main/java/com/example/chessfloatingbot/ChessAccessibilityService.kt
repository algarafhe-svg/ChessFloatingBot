package com.example.chessfloatingbot

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.Path
import android.os.Build
import android.view.accessibility.AccessibilityEvent

class ChessAccessibilityService : AccessibilityService() {
    private val gestures = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            if (intent?.action != ACTION_EXECUTE_MOVE) return
            val x1=intent.getFloatExtra("fromX",-1f); val y1=intent.getFloatExtra("fromY",-1f)
            val x2=intent.getFloatExtra("toX",-1f); val y2=intent.getFloatExtra("toY",-1f)
            if (x1<0 || y1<0 || x2<0 || y2<0) return
            val path=Path().apply { moveTo(x1,y1); lineTo(x2,y2) }
            val gesture=GestureDescription.Builder().addStroke(GestureDescription.StrokeDescription(path,0,420)).build()
            dispatchGesture(gesture, object: GestureResultCallback() {
                override fun onCompleted(gestureDescription: GestureDescription?) {
                    sendBroadcast(Intent(ACTION_GESTURE_RESULT).setPackage(packageName).putExtra("ok",true))
                }
                override fun onCancelled(gestureDescription: GestureDescription?) {
                    sendBroadcast(Intent(ACTION_GESTURE_RESULT).setPackage(packageName).putExtra("ok",false))
                }
            }, null)
        }
    }
    override fun onServiceConnected() {
        super.onServiceConnected()
        val f=IntentFilter(ACTION_EXECUTE_MOVE)
        if(Build.VERSION.SDK_INT>=33) registerReceiver(gestures,f,Context.RECEIVER_NOT_EXPORTED)
        else {
            @Suppress("DEPRECATION")
            registerReceiver(gestures, f)
        }
    }
    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}
    override fun onDestroy() { try{unregisterReceiver(gestures)}catch(_:Exception){}; super.onDestroy() }
    companion object {
        const val ACTION_EXECUTE_MOVE="com.example.chessfloatingbot.EXECUTE_MOVE"
        const val ACTION_GESTURE_RESULT="com.example.chessfloatingbot.GESTURE_RESULT"
    }
}
