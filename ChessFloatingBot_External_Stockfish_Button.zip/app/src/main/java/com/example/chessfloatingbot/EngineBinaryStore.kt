package com.example.chessfloatingbot

import android.content.Context
import android.net.Uri
import android.os.Build
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream

/** Imports an Android-native Stockfish ELF executable into private app storage. */
object EngineBinaryStore {
    private const val FILE_NAME = "stockfish_external"
    private const val PREFS = "engine_settings"
    private const val KEY_EXTERNAL = "use_external"

    fun importEngine(context: Context, uri: Uri): File {
        val destination = File(context.filesDir, FILE_NAME)
        val temporary = File(context.filesDir, "$FILE_NAME.tmp")
        context.contentResolver.openInputStream(uri).use { input ->
            requireNotNull(input) { "تعذر فتح ملف المحرك المحدد" }
            FileOutputStream(temporary).use { output -> input.copyTo(output) }
        }
        validateElf(temporary)
        require(temporary.setExecutable(true, true) || temporary.canExecute()) {
            "تعذر منح ملف المحرك صلاحية التنفيذ"
        }
        if (destination.exists()) destination.delete()
        check(temporary.renameTo(destination)) { "تعذر حفظ ملف المحرك في مساحة التطبيق" }
        check(destination.setExecutable(true, true) || destination.canExecute()) {
            "تعذر تفعيل صلاحية تنفيذ المحرك"
        }
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
            .putBoolean(KEY_EXTERNAL, true).apply()
        return destination
    }

    fun useBundled(context: Context) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
            .putBoolean(KEY_EXTERNAL, false).apply()
    }

    fun selected(context: Context): File {
        val external = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .getBoolean(KEY_EXTERNAL, false)
        if (external) {
            val file = File(context.filesDir, FILE_NAME)
            require(file.exists() && file.canExecute()) {
                "المحرك الخارجي المحدد غير موجود أو غير قابل للتنفيذ؛ أعد إضافته"
            }
            return file
        }
        return File(context.applicationInfo.nativeLibraryDir, "libstockfish.so")
    }

    private fun validateElf(file: File) {
        FileInputStream(file).use { stream ->
            val h = ByteArray(20)
            require(stream.read(h) == h.size) { "الملف قصير وليس محركاً صالحاً" }
            require(h[0] == 0x7f.toByte() && h[1] == 69.toByte() &&
                h[2] == 76.toByte() && h[3] == 70.toByte()) {
                "الملف ليس ELF تنفيذياً؛ اختر ملف Stockfish المخصص لـ Android"
            }
            require(h[5].toInt() == 1) { "تنسيق ELF غير مدعوم؛ يلزم Little Endian" }
            val machine = (h[18].toInt() and 255) or ((h[19].toInt() and 255) shl 8)
            val abis = Build.SUPPORTED_ABIS.toList()
            val compatible = when (machine) {
                183 -> "arm64-v8a" in abis
                40 -> "armeabi-v7a" in abis || "armeabi" in abis
                62 -> "x86_64" in abis
                3 -> "x86" in abis
                else -> false
            }
            require(compatible) {
                "معمارية المحرك لا تطابق الهاتف. معمارية الملف=$machine؛ الهاتف=${abis.joinToString()}"
            }
        }
    }
}
