package com.example.chessfloatingbot

import android.graphics.Bitmap
import android.graphics.RectF
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sqrt

/**
 * Converts a screenshot bitmap into normalized FEN.
 * The board locator searches for an 8x8 alternating-square color grid at multiple scales.
 * The pipeline refuses uncertain cells rather than inventing piece identities.
 */
class BoardVisionPipeline(private val recognizer: TemplatePieceRecognizer) {
    data class Result(val fen: String, val boardBounds: RectF, val detectedPieces: Int, val confidence: Double)
    data class Failure(val reason: String)

    fun analyze(screen: Bitmap, bottomPlayerToMove: Boolean): Result? {
        val bounds = locateBoard(screen) ?: return null
        val side = bounds.width() / 8f
        val squares = MutableList<BoardFenEncoder.DetectedPiece?>(64) { null }
        var count = 0
        var confidence = 0.0
        for (row in 0..7) {
            for (col in 0..7) {
                val left = bounds.left + col * side
                val top = bounds.top + row * side
                val margin = side * 0.13f
                val cell = Bitmap.createBitmap(
                    screen,
                    (left + margin).toInt().coerceIn(0, screen.width-1),
                    (top + margin).toInt().coerceIn(0, screen.height-1),
                    max(1, (side - 2*margin).toInt()).coerceAtMost(screen.width - (left+margin).toInt()),
                    max(1, (side - 2*margin).toInt()).coerceAtMost(screen.height - (top+margin).toInt())
                )
                val candidateExists = recognizer.hasPieceCandidate(cell)
                val match = try { recognizer.classify(cell) } finally { cell.recycle() }
                if (candidateExists && match == null) return null
                if (match != null) {
                    squares[row*8+col] = BoardFenEncoder.DetectedPiece(match.kind, match.belongsToBottomPlayer)
                    count++; confidence += match.score
                }
            }
        }
        // A real board has exactly 32 pieces at the initial position, but later game
        // states may have fewer. Require both kings and at least 2 detected pieces.
        if (count < 4 || count > 32) return null
        val pieces = squares.filterNotNull()
        val bottomKings = pieces.count { it.kind == 'k' && it.belongsToBottomPlayer }
        val topKings = pieces.count { it.kind == 'k' && !it.belongsToBottomPlayer }
        if (bottomKings != 1 || topKings != 1) return null
        val fen = BoardFenEncoder.encode(BoardFenEncoder.Position(squares, bottomPlayerToMove))
        return Result(fen, bounds, count, confidence / count)
    }

    private fun locateBoard(bitmap: Bitmap): RectF? {
        // Find the outer square frame from averaged horizontal/vertical edge profiles.
        // This avoids the half-square phase ambiguity of checkerboard-center sampling.
        val w=bitmap.width; val h=bitmap.height
        fun luminance(c:Int):Double = 0.299*((c shr 16) and 255)+0.587*((c shr 8) and 255)+0.114*(c and 255)
        val vertical=DoubleArray(w)
        for(x in 4 until w-4) {
            var sum=0.0; var n=0
            for(y in 0 until h step 4) { sum += kotlin.math.abs(luminance(bitmap.getPixel(x-3,y))-luminance(bitmap.getPixel(x+3,y))); n++ }
            vertical[x]=sum/n
        }
        val horizontal=DoubleArray(h)
        for(y in 4 until h-4) {
            var sum=0.0; var n=0
            for(x in 0 until w step 4) { sum += kotlin.math.abs(luminance(bitmap.getPixel(x,y-3))-luminance(bitmap.getPixel(x,y+3))); n++ }
            horizontal[y]=sum/n
        }
        val minSide=min(w,h)*0.76
        val maxSide=min(w,h)*0.96
        var bestX1=-1; var bestX2=-1; var bestXScore=0.0
        for(x1 in (w*0.015).toInt()..(w*0.16).toInt()) {
            for(x2 in (w*0.84).toInt()..(w*0.985).toInt()) {
                val side=(x2-x1).toDouble()
                if(side !in minSide..maxSide) continue
                val centerError=kotlin.math.abs((x1+x2)/2.0-w/2.0)/w
                if(centerError>0.035) continue
                val score=vertical[x1]+vertical[x2]-centerError*80
                if(score>bestXScore) { bestXScore=score; bestX1=x1; bestX2=x2 }
            }
        }
        if(bestX1<0) return null
        val side=bestX2-bestX1
        var bestY1=-1; var bestY2=-1; var bestYScore=0.0
        val tolerance=(side*0.045).toInt()
        for(y1 in (h*0.12).toInt()..(h*0.62).toInt()) {
            val expected=y1+side
            for(y2 in (expected-tolerance).coerceAtLeast(4)..(expected+tolerance).coerceAtMost(h-5)) {
                val center=(y1+y2)/2.0
                if(center !in (h*0.25)..(h*0.78)) continue
                val score=horizontal[y1]+horizontal[y2]
                if(score>bestYScore) { bestYScore=score; bestY1=y1; bestY2=y2 }
            }
        }
        if(bestY1<0) return null
        val bounds=RectF(bestX1.toFloat(),bestY1.toFloat(),bestX2.toFloat(),bestY2.toFloat())
        val checker=checkerScore(bitmap,bounds.left,bounds.top,bounds.width()/8f)
        return bounds.takeIf { checker>0.035 && bestXScore>15 && bestYScore>15 }
    }

    private fun boardEdgeScore(bitmap: Bitmap, x: Float, y: Float, side: Float): Double {
        fun distance(a: Int, b: Int): Double {
            val dr=((a shr 16) and 255)-((b shr 16) and 255)
            val dg=((a shr 8) and 255)-((b shr 8) and 255)
            val db=(a and 255)-(b and 255)
            return sqrt((dr*dr+dg*dg+db*db).toDouble()) / 441.7
        }
        var total=0.0; var n=0
        for(i in 1..7) {
            val yy=(y+side*i/8f).toInt().coerceIn(4,bitmap.height-5)
            val xx=(x+side*i/8f).toInt().coerceIn(4,bitmap.width-5)
            val lx=x.toInt(); val rx=(x+side).toInt()
            val ty=y.toInt(); val by=(y+side).toInt()
            if(lx>=4 && rx<bitmap.width-4) {
                total += distance(bitmap.getPixel(lx-3,yy),bitmap.getPixel(lx+3,yy))
                total += distance(bitmap.getPixel(rx-3,yy),bitmap.getPixel(rx+3,yy)); n+=2
            }
            if(ty>=4 && by<bitmap.height-4) {
                total += distance(bitmap.getPixel(xx,ty-3),bitmap.getPixel(xx,ty+3))
                total += distance(bitmap.getPixel(xx,by-3),bitmap.getPixel(xx,by+3)); n+=2
            }
        }
        return if(n==0)0.0 else total/n
    }

    private fun checkerScore(bitmap: Bitmap, x: Float, y: Float, cell: Float): Double {
        val colors = ArrayList<Int>(64)
        for (r in 0..7) for (c in 0..7) {
            val px = (x + (c+0.5f)*cell).toInt().coerceIn(0, bitmap.width-1)
            val py = (y + (r+0.5f)*cell).toInt().coerceIn(0, bitmap.height-1)
            colors += bitmap.getPixel(px,py)
        }
        var unlike = 0.0
        var like = 0.0
        var unlikeN = 0
        var likeN = 0
        fun colorDistance(a: Int, b: Int): Double {
            val dr=((a shr 16) and 255)-((b shr 16) and 255)
            val dg=((a shr 8) and 255)-((b shr 8) and 255)
            val db=(a and 255)-(b and 255)
            return kotlin.math.sqrt((dr*dr+dg*dg+db*db).toDouble())
        }
        for (r in 0..7) for (c in 0..7) {
            val i=r*8+c
            if (c<7) { unlike += colorDistance(colors[i],colors[i+1]); unlikeN++ }
            if (r<7) { unlike += colorDistance(colors[i],colors[i+8]); unlikeN++ }
            if (r<7 && c<7) { like += colorDistance(colors[i],colors[i+9]); likeN++ }
            if (r<7 && c>0) { like += colorDistance(colors[i],colors[i+7]); likeN++ }
        }
        val contrast = (unlike / max(1, unlikeN)) - (like / max(1, likeN))
        return (contrast / 255.0).coerceAtLeast(0.0)
    }
}
