package com.example.chessfloatingbot

import org.junit.Assert.*
import org.junit.Test

class UciParsingTest {
    @Test fun startingPositionFenIsWellFormed() {
        val fen = "rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1"
        assertEquals(6, fen.split(' ').size)
        assertTrue(fen.startsWith("rnbqkbnr/"))
    }
    @Test fun uciMoveHasFourOrFiveCharacters() {
        assertTrue("e2e4".matches(Regex("[a-h][1-8][a-h][1-8][qrbn]?")))
        assertTrue("e7e8q".matches(Regex("[a-h][1-8][a-h][1-8][qrbn]?")))
        assertFalse("e9e4".matches(Regex("[a-h][1-8][a-h][1-8][qrbn]?")))
    }
}
