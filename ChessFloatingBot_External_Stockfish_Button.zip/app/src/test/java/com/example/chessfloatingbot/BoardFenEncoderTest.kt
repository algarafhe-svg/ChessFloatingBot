package com.example.chessfloatingbot

import org.junit.Assert.*
import org.junit.Test

class BoardFenEncoderTest {
    @Test fun bottomSideIsAlwaysNormalizedToWhite() {
        val squares = MutableList<BoardFenEncoder.DetectedPiece?>(64) { null }
        squares[60] = BoardFenEncoder.DetectedPiece('k', true)   // e1
        squares[4] = BoardFenEncoder.DetectedPiece('k', false)  // e8
        squares[52] = BoardFenEncoder.DetectedPiece('p', true)  // e2
        squares[12] = BoardFenEncoder.DetectedPiece('p', false) // e7
        val fen = BoardFenEncoder.encode(BoardFenEncoder.Position(squares, true))
        assertEquals("4k3/4p3/8/8/8/8/4P3/4K3 w - - 0 1", fen)
    }

    @Test fun bottomPlayerMayMoveSecondWithoutChangingPieceIdentity() {
        val squares = MutableList<BoardFenEncoder.DetectedPiece?>(64) { null }
        squares[60] = BoardFenEncoder.DetectedPiece('k', true)
        squares[4] = BoardFenEncoder.DetectedPiece('k', false)
        val fen = BoardFenEncoder.encode(BoardFenEncoder.Position(squares, false))
        assertTrue(fen.endsWith(" b - - 0 1"))
        assertTrue(fen.contains("4k3"))
        assertTrue(fen.contains("4K3"))
    }

    @Test fun rejectsWrongSquareCount() {
        try {
            BoardFenEncoder.encode(BoardFenEncoder.Position(emptyList(), true))
            fail("Expected invalid board size")
        } catch (_: IllegalArgumentException) {}
    }
}
